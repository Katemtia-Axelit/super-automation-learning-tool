# 工作邮箱系统说明

> 用途：让总控与各员工通过项目内文件进行收发件、汇报、归档，减少复制粘贴。
> 版本：1.0 | 日期：2026-06-10

---

## 一、系统目标

工作邮箱系统用于解决以下问题：

1. 总控发工单时，不再需要每次手动复制长文本到聊天框
2. 员工领取任务时，有固定位置查看属于自己的工单
3. 员工提交汇报时，有固定位置投递报告
4. 总控检查工作时，只需要统一查看“收件箱”
5. 已完成或过期的工单、报告可以统一归档，保持环境干净
6. 每轮工作都留下记录，形成可追溯的团队工作档案

---

## 二、目录结构

工作邮箱根目录：`docs/ai_team/work_mailbox/`

建议结构如下：

- `docs/ai_team/work_mailbox/README.md` —— 本说明文件
- `docs/ai_team/work_mailbox/inbox/manager/` —— 总控收件箱（员工投递报告到这里）
- `docs/ai_team/work_mailbox/inbox/01_frontend_backend/` —— 01 员工收件箱
- `docs/ai_team/work_mailbox/inbox/02_rules_architecture/` —— 02 员工收件箱
- `docs/ai_team/work_mailbox/inbox/03_knowledge_engineering/` —— 03 员工收件箱
- `docs/ai_team/work_mailbox/inbox/04_prompt_review/` —— 04 员工收件箱
- `docs/ai_team/work_mailbox/inbox/05_fast_executor/` —— 05 员工收件箱
- `docs/ai_team/work_mailbox/archive/dispatches/` —— 已完成或过期工单归档
- `docs/ai_team/work_mailbox/archive/reports/` —— 已完成报告归档
- `docs/ai_team/work_mailbox/archive/logs/` —— 工作经历日志归档
- `docs/ai_team/work_mailbox/templates/` —— 邮箱工单/报告模板

---

## 三、谁往哪里投递

### 1）总控发工单

总控给某员工发工单时：
- 把工单写入该员工自己的收件箱
- 例如：给 02 发工单，就写入 `docs/ai_team/work_mailbox/inbox/02_rules_architecture/`

### 2）员工交报告

员工完成任务后：
- 把报告写入 `docs/ai_team/work_mailbox/inbox/manager/`
- 报告文件名里必须注明自己的员工编号和对应工单编号

### 3）总控检查工作邮箱

当用户说“请检查工作邮箱”时，总控需要：
1. 检查 `docs/ai_team/work_mailbox/inbox/manager/` 是否有新增报告
2. 检查各员工收件箱里是否有待领取工单
3. 判断哪些工单已过期、已完成、重复、误投
4. 删除或归档已过期指令与已处理报告
5. 把本轮处理结果写入工作日志

---

## 四、命名规范

### 工单文件命名

```text
[状态]_[工单编号]_[员工编号]_[任务短名].md
```

示例：
- `TODO_P1.6_02_项目结构清理体检.md`
- `TODO_P1.7_01_执行结构清理.md`

### 报告文件命名

```text
[状态]_[工单编号]_[员工编号]_REPORT_[任务短名].md
```

示例：
- `DONE_P1.6_02_REPORT_项目结构清理体检.md`
- `DONE_P1.3_03_REPORT_笔记整理流程审查.md`

### 日志文件命名

```text
yyyy-mm-dd_[轮次说明].md
```

示例：
- `2026-06-10_首轮派工处理日志.md`

---

## 五、状态规范

### 工单状态

- `TODO` —— 待领取
- `DOING` —— 已领取，处理中
- `BLOCKED` —— 被阻塞，需要总控决策
- `DONE` —— 员工已完成，等待总控处理
- `ARCHIVED` —— 已归档
- `EXPIRED` —— 已过期，不再执行

### 报告状态

- `DONE` —— 已提交，等待总控审阅
- `REVIEWED` —— 已被总控审阅
- `ARCHIVED` —— 已归档
- `REJECTED` —— 总控退回，要求重做

---

## 六、员工领取规则

每个员工必须遵守：

1. 只检查并领取自己收件箱中的工单
2. 不要抢别人的工单
3. 不要处理文件名中员工编号不属于自己的工单
4. 如果自己收件箱中没有新工单，就等待，不主动揽活
5. 领取工单后，应把工单文件状态从 `TODO` 改成 `DOING`
6. 完成后，提交报告到总控收件箱，不要直接修改原工单为结论文档

---

## 七、总控处理规则

总控必须遵守：

1. **只允许通过工作邮箱派工**，不要再创建 `docs/ai_team/首批派工单/` 之类的独立工单目录
2. 每次发工单时，只投递到目标员工自己的收件箱
3. 每次审阅完成后，把原工单和报告及时归档
4. 对过期、重复、误投的工单要及时清理
5. 每一轮收发件结束后，写一份日志到 `archive/logs/`
6. 当用户说“请检查工作邮箱”时，总控必须优先处理邮箱，而不是直接开始新任务
7. 每次成功派工后，总控要提醒用户：你应该跟对应员工说“检查邮箱”

---

## 八、归档规则

### 工单归档

以下情况要归档到 `archive/dispatches/`：
- 已执行完毕的工单
- 已被替代的新版本工单
- 已过期不再执行的工单
- 误发但已确认不再处理的工单

### 报告归档

以下情况要归档到 `archive/reports/`：
- 已被总控审阅完毕的报告
- 被退回重做前，需要留档的旧报告

### 工作日志归档

每轮处理后，总控写入日志，至少记录：
- 本轮检查时间
- 新增工单数
- 新增报告数
- 已归档工单数
- 已归档报告数
- 需要用户决策的问题

---

## 九、推荐模板位置

模板统一放在：
- `docs/ai_team/work_mailbox/templates/工单模板.md`
- `docs/ai_team/work_mailbox/templates/报告模板.md`
- `docs/ai_team/work_mailbox/templates/工作日志模板.md`

---

## 十、总控触发词

当用户说以下话时，总控应自动进入邮箱流程：

- “请检查工作邮箱”
- “看看有没有新报告”
- “检查员工有没有新工单”
- “清理一下工作邮箱”
- “归档本轮工作”

这些指令默认意味着：
- 检查 `manager` 收件箱
- 检查各员工收件箱
- 归档已处理文件
- 更新本轮工作日志

# P2.1【第一组：半导体基础与二极管】笔记重构

- 工单编号：P2.1
- 员工编号：03
- 状态：DONE
- 完成时间：2026-06-11
- 创建时间：2026-06-11 12:14
- 创建人：总控经理

---

## 一、任务说明

你是 **03 知识工程师**，你的核心职责是把讲义内容重构为结构清晰、图文并茂、可供初学者自学复习的知识笔记。

**本次任务：重构第1组笔记——半导体基础与二极管。**

### 必须使用的工具

在开始工作前，你必须确保以下工具可用（使用前先验证 import 成功）：

```python
# PPT 解析：提取嵌入图片和文字
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os, shutil, hashlib

# 图片处理：裁剪、去背景
from PIL import Image
from PIL import ImageDraw, ImageFont

# PDF 解析（备用，用于教师PDF讲义）
import fitz  # PyMuPDF
```

如果 `fitz` 未安装，执行：
```bash
pip install PyMuPDF
```

如果图片去背景需要更多工具，执行：
```bash
pip install rembg
```

### PPT 文件路径

请使用以下路径读取 PPT 文件（Windows 路径）：

```
D:\Axelit\工作\trae\超级自动化学习工具\data\讲义\第1章  半导体基础知识.ppt
D:\Axelit\工作\trae\超级自动化学习工具\data\讲义\第2章  二极管与整流电路.ppt
```

注意：文件名可能有空格不一致，请用 `os.listdir("D:/Axelit/工作/trae/超级自动化学习工具/data/讲义/")` 列出实际文件名后再精确匹配。

### 现有笔记路径

```
D:\Axelit\工作\trae\超级自动化学习工具\src\notes\vault\电子技术\01_半导体基础与PN结.md
D:\Axelit\工作\trae\超级自动化学习工具\src\notes\vault\电子技术\02_二极管特性与等效模型.md
```

---

## 二、你的身份

你是 03 知识工程师，本次只负责**知识重构**，不要越权处理其他赛道问题。

---

## 三、本次目标

重构第1组（半导体基础 + 二极管）的笔记，做到：

1. **内容完整**：覆盖 PPT 中所有重要知识点，不遗漏
2. **图表丰富**：每个核心概念配有解析图（从 PPT 提取的原始图片、表格，或重新绘制的电路图）
3. **文字清晰**：说明文字由笔记自己完成，图片呈现的是让人容易看懂的解析图、原理图，配上适当标注，而非把带密密麻麻小字的 PPT 页面连汤带水地插入
4. **适合初学**：任何零基础学习者都能通过笔记理解概念
5. **保留例题**：PPT 中的例题必须保留并给出详细解题步骤

---

## 四、工作流程（必须严格按顺序执行）

### 步骤1：分析现有笔记的问题

先阅读现有笔记（01 和 02），明确当前存在的问题：
- 哪些地方过于简略？
- 哪些地方缺少图表？
- 哪些地方逻辑不通顺？

### 步骤2：读取 PPT 内容

使用 python-pptx 逐页读取 PPT，**提取每页中嵌入的图片**（而非转文字）：

```python
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os, hashlib

ppt_path = "D:/Axelit/工作/trae/超级自动化学习工具/data/讲义/第2章  二极管与整流电路.ppt"
prs = Presentation(ppt_path)

for slide_idx, slide in enumerate(prs.slides):
    slide_title = ""
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                if para.text.strip():
                    slide_title = para.text.strip()
                    break
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            # 提取图片
            image = shape.image
            img_bytes = image.blob
            img_ext = image.ext
            img_hash = hashlib.md5(img_bytes).hexdigest()[:8]
            out_path = f"extracted_pics/ch02/{slide_idx+1:03d}_{img_hash}.{img_ext}"
            os.makedirs(os.path.dirname(out_path), exist_ok=True)
            with open(out_path, "wb") as f:
                f.write(img_bytes)
            print(f"Slide {slide_idx+1}: Extracted image -> {out_path} (title: {slide_title})")
        elif hasattr(shape, "table"):
            # 提取表格
            table = shape.table
            print(f"Slide {slide_idx+1}: Table with {len(table.rows)} rows x {len(table.columns)} cols (title: {slide_title})")
```

### 步骤3：处理图片

对于提取到的图片，按以下策略处理：

| 图片类型 | 处理方式 |
|----------|----------|
| 电路原理图（干净、无文字遮挡） | 直接使用，存入 `src/notes/vault/diagrams/电子技术/` |
| 带大量文字的 PPT 页面截图 | **不要直接使用**。尝试裁剪出纯净的电路图部分使用，或标记为"需重绘" |
| 波形图、数据图 | 如果清晰可直接使用 |
| 表格 | 转成 Markdown 表格 |

### 步骤4：重构笔记

按以下模板重构笔记（参考现有 02 笔记的格式）：

```markdown
# [章节标题]

## [核心概念]
[文字说明，逻辑清晰，适合初学者]

![解析图说明](diagrams_path)
> **配图分析**：[解释图中关键元素，不超过3句话]

## [应用/例题]
### 例题
[题目原文]

**解题步骤：**
1. ...
2. ...
3. ...

**结果：** ...
```

### 步骤5：AI 绘制电路图（仅限经批准后）

如果某页 PPT 中的电路图无法提取纯净图片（页面以讲述为主，图表与文字混杂），则：

1. 先尝试裁剪：使用 PIL 从整页图片中裁剪出纯净电路图区域
2. 如果裁剪后仍带大量文字或效果不佳，**停止**，在报告中标注"该图需 AI 绘制，待总控和用户批准"
3. **不要**在未获批准的情况下自行绘制

---

## 五、禁止事项

- 不要把 PPT 页面截图直接插入笔记（密密麻麻的文字无法阅读）
- 不要跳过现有笔记的阅读（必须先了解当前状态）
- 不要越权处理不属于你职责范围的问题
- 不要跳过步骤，必须按 步骤1~5 顺序执行
- 不得在未获批准前自行绘制电路图

---

## 六、汇报格式

完成后报告投递到：`docs/ai_team/work_mailbox/inbox/manager/`
文件名：`DONE_P2.1_03_REPORT_第一组笔记重构.md`

## 七、提示

- 第一组完成并提交报告后，请继续查看邮箱领取 **P2.2**（第二组：三极管）
- 如果遇到无法解决的困难（如 PPT 文件损坏、解析失败），**立即停止**并向总控汇报，不要试图绕过
- PPT 文件可能较大（18MB），解析可能需要较长时间，耐心等待
- 如果 Python 脚本遇到 `Path(__file__)` 相关错误（之前的工具脚本有这个问题），使用绝对路径

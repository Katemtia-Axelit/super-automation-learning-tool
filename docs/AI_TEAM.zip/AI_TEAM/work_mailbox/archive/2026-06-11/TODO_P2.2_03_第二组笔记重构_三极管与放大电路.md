# P2.2【第二组：三极管与放大电路】笔记重构

- 工单编号：P2.2
- 员工编号：03
- 状态：BLOCKED
- 阻塞时间：2026-06-11
- 阻塞原因：见下方报告
- 创建时间：2026-06-11 12:14
- 创建人：总控经理

---

## 一、任务说明

你是 **03 知识工程师**，你的核心职责是把讲义内容重构为结构清晰、图文并茂、可供初学者自学复习的知识笔记。

**本次任务：重构第2组笔记——三极管与放大电路。**

### 必须使用的工具

```python
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
from PIL import Image
import os, hashlib
```

### PPT 文件路径

```
D:\Axelit\工作\trae\超级自动化学习工具\data\讲义\第3章  三极管与放大电路.ppt
```

（请用 `os.listdir("D:/Axelit/工作/trae/超级自动化学习工具/data/讲义/")` 确认实际文件名）

### 现有笔记路径

```
D:\Axelit\工作\trae\超级自动化学习工具\src\notes\vault\电子技术\03_半导体三极管原理.md
D:\Axelit\工作\trae\超级自动化学习工具\src\notes\vault\电子技术\06_三极管放大电路——静态分析.md
D:\Axelit\工作\trae\超级自动化学习工具\src\notes\vault\电子技术\07_三极管放大电路——动态分析与多级放大.md
```

---

## 二、你的身份

你是 03 知识工程师，本次只负责**知识重构**，不要越权处理其他赛道问题。

---

## 三、本次目标

重构第2组（三极管原理 + 静态分析 + 动态分析）的笔记，做到：

1. **内容完整**：覆盖 PPT 中所有重要知识点
2. **图表丰富**：每个核心概念配有解析图（从 PPT 提取的原始图片、表格，或重新绘制的电路图）
3. **文字清晰**：说明文字由笔记自己完成，图片呈现的是让人容易看懂的解析图、原理图，配上适当标注，而非把带密密麻麻小字的 PPT 页面连汤带水地插入
4. **适合初学**：任何零基础学习者都能通过笔记理解概念
5. **保留例题**：PPT 中的例题必须保留并给出详细解题步骤

---

## 四、工作流程

### 步骤1：分析现有笔记的问题

先阅读现有笔记（03、06、07），明确当前存在的问题。

### 步骤2：读取 PPT 内容

使用 python-pptx 逐页读取 PPT，提取嵌入图片：

```python
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os, hashlib

ppt_path = "D:/Axelit/工作/trae/超级自动化学习工具/data/讲义/第3章  三极管与放大电路.ppt"
prs = Presentation(ppt_path)

for slide_idx, slide in enumerate(prs.slides):
    for shape in slide.shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            image = shape.image
            img_bytes = image.blob
            img_hash = hashlib.md5(img_bytes).hexdigest()[:8]
            img_ext = image.ext
            out_path = f"extracted_pics/ch03/{slide_idx+1:03d}_{img_hash}.{img_ext}"
            os.makedirs(os.path.dirname(out_path), exist_ok=True)
            with open(out_path, "wb") as f:
                f.write(img_bytes)
```

### 步骤3：处理图片

| 图片类型 | 处理方式 |
|----------|----------|
| 电路原理图（干净、无文字遮挡） | 直接使用，存入 `src/notes/vault/diagrams/电子技术/` |
| 带大量文字的 PPT 页面截图 | **不要直接使用**。尝试裁剪出纯净的电路图部分，或标记"需AI绘制" |
| 波形图、数据图 | 清晰则直接使用 |
| 表格 | 转成 Markdown 表格 |

### 步骤4：重构笔记

参考 03/06/07 现有笔记的格式，重构优化：
- 每个核心概念配有解析图
- 说明文字由笔记自己完成
- 图片是让人容易看懂的原理图，而非 PPT 页面截图
- 保留 PPT 中的例题并给出详细解题步骤

### 步骤5：AI 绘制电路图（仅限经批准后）

如果某页 PPT 中的电路图无法提取纯净图片，先尝试裁剪。如果效果仍不好，**停止并标注"需AI绘制"**，等待总控和用户批准。

---

## 五、禁止事项

- 不要把 PPT 页面截图直接插入笔记
- 不要跳过现有笔记的阅读（必须先了解当前状态）
- 不要越权处理不属于你职责范围的问题
- 不要跳过步骤，必须按步骤1~5顺序执行
- 不得在未获批准前自行绘制电路图

---

## 六、汇报格式

完成后报告投递到：`docs/ai_team/work_mailbox/inbox/manager/`
文件名：`DONE_P2.2_03_REPORT_第二组笔记重构.md`

## 七、提示

- 第二组完成并提交报告后，请继续查看邮箱领取 **P2.3**（第三组：直流稳压电源）
- 如果遇到无法解决的困难（如 PPT 文件损坏、解析失败），**立即停止**并向总控汇报

# P3.1【文件结构彻底清理】任务派工

- 工单编号：P3.1
- 员工编号：05
- 状态：DOING
- 创建时间：2026-06-11 15:15
- 创建人：总控经理

---

## 一、任务说明

你是 **05 快速执行员**。本次任务是对项目根目录、`tools/`、`scripts/`、`src/notes/` 进行彻底的文件结构清理，消除乱放现象，建立规范。

> ⚠️ **重要路径修正**：项目根目录下的 AI 团队文档目录为 `docs/AI_TEAM/`（注意大小写），**不是** `docs/ai_team/`。所有后续路径均使用正确大小写。

---

## 二、总控确认（05 的四个问题）

### Q1：`docs/ai_team/` 是否就是 `docs/AI_TEAM/`？
**✅ 是的**。Windows 文件系统默认大小写不敏感，`docs/ai_team/` 和 `docs/AI_TEAM/` 指向同一目录。工单中的路径已全部更正为 `docs/AI_TEAM/`。

### Q2：根目录的 `__pycache__`、`.venv`、`.python`、`.run` 是否需要处理？

| 目录 | 总控决策 |
|------|---------|
| `__pycache__/` | ✅ **删除**（Python 运行时缓存，可随时重建） |
| `.venv/` | ❌ **保留**（Python 虚拟环境，开发依赖） |
| `.python/` | ❌ **保留**（Python 配置目录） |
| `.run/` | ✅ **清理内部日志文件**（`.run/server.log` 可清空；`.run/server.pid` 删除；`.run/*.layout-bak` 删除）；保留 `.run/` 目录本身（VS Code 运行时需要） |

### Q3：`ai_workspace/`、`config/`、`server/`、`static/` 的处理方式？

| 目录 | 总控决策 |
|------|---------|
| `ai_workspace/` | ❌ **保留**（AI 团队工作空间目录，有实际内容） |
| `config/` | ❌ **保留**（项目配置目录，有 `config.json`） |
| `server/` | ❌ **保留**（后端服务目录，`backend_api.py` 等） |
| `static/` | ❌ **保留**（Web 静态资源目录，`app.js` 等） |

### Q4：`extracted_pics/` 应移入 `data/` 还是 `src/notes/`？

**→ 移入 `src/notes/extracted_pics/`**。该目录存放的是笔记相关的提取图片，与 `src/notes/vault/diagrams/` 和 `src/notes/vault/extracted_pics/` 同类，归入 `src/notes/` 更合理。移动后记得更新所有引用该目录的笔记文件。

---

## 三、当前问题（必须全部处理）

---

## 二、当前问题（必须全部处理）

### 问题A：根目录乱放（最严重）

根目录 `D:\Axelit\工作\trae\超级自动化学习工具\` 下有大量本应归属其他目录的文件：

#### A1：Python 脚本（应移入 `scripts/`）

```
根目录/_check_ppt_format.py     → scripts/
根目录/_check_svg.py            → scripts/
根目录/_crop_ch4_ch7_ch8.py     → scripts/
根目录/_crop_ch5_ch6.py         → scripts/
根目录/_crop_diagrams.py        → scripts/
根目录/_crop_extra.py           → scripts/
根目录/_crop_extra2.py          → scripts/
根目录/_crop_more.py            → scripts/
根目录/_extract_ppt.py          → scripts/
根目录/_extract_ppt_ch3.py      → scripts/
根目录/_extract_ppt_ch34.py     → scripts/
根目录/_extract_ppt_text.py     → scripts/
根目录/_read_exact.py           → scripts/
根目录/check_deps.py            → scripts/
根目录/main.py                  → scripts/
```

#### A2：JSON 数据文件（应移入 `data/extracted/` 或 `scripts/`）

```
根目录/_slides_ch01.json        → data/extracted/
根目录/_slides_ch02.json        → data/extracted/
根目录/_slides_ch3文.json       → data/extracted/
根目录/_slides_ch4文.json       → data/extracted/
根目录/_tmp_files.json          → data/extracted/
```

#### A3：JSON 配置（可保留根目录）

```
根目录/opencode.json            → 保留（项目配置）
```

#### A4：Markdown 文档（应移入 `docs/` 或 `src/notes/vault/`）

```
根目录/PROJECT_DOCUMENTATION.md  → docs/  或  src/notes/vault/项目文档/
根目录/README.md                 → 保留根目录（项目入口说明）
根目录/requirements-web.txt      → 保留
根目录/requirements.txt         → 保留
```

#### A5：批处理脚本（应移入 `scripts/`）

```
根目录/check_deps.py 已在 A1 中处理
（无 .bat 文件在根目录，无需处理）
```

#### A5：VS Code 运行配置清理（`.run/`）

```
根目录/.run/server.log      →  **清空**（约859KB日志）
根目录/.run/server.pid     →  **删除**（运行时PID，进程结束后无用）
根目录/.run/app.js.layout-bak  →  删除（VS Code 布局备份）
根目录/.run/index.html.layout-bak  →  删除
根目录/.run/               →  **保留目录本身**（VS Code 运行时需要）
```

#### A6：其他根目录文件

```
根目录/index.html              →  src/  （Web 前端入口文件）
根目录/index_original.html     →  删除（0字节空文件，无意义）
根目录/.gitignore             →  保留（Git 标准配置）
根目录/超级自动化学习工具.bat  →  scripts/
根目录/PROJECT_DOCUMENTATION.md →  docs/项目文档/ （先创建 docs/项目文档/ 目录）
根目录/requirements-web.txt    →  保留（项目依赖）
根目录/requirements.txt        →  保留（项目依赖）
```

### 问题B：`scripts/` 内部版本混乱

`scripts/` 下存在大量同系列脚本的多版本，应合并：

| 系列 | 文件 | 建议 |
|------|------|------|
| extract_ppt | `extract_all_ppts.py`, `extract_ppt_all.py`, `extract_ppt_diagrams.py`, `extract_remaining_ppts.py` | 保留 `extract_ppt_all.py`（最全），其余移入 `scripts/archive/` |
| fix_tables | `fix_tables.py`, `fix_tables_final.py`, `fix_tables_v2.py`, `fix_tables_v3.py` | 保留 `fix_tables_final.py`，其余移入 `scripts/archive/` |
| fix_paths | `fix_backslash_binary.py`, `fix_double_backslash.py`, `fix_last_4.py`, `fix_missing_columns.py`, `fix_paths.py`, `fix_path_separators.py`, `fix_remaining.py`, `fix_single_backslash.py` | 保留 `fix_path_separators.py`（覆盖最广），其余移入 `scripts/archive/` |
| check_links | `check_links.py`, `check_links_v2.py` | 保留 `check_links_v2.py`，旧版移入 `scripts/archive/` |
| read_docx | `read_docx.py`, `read_docx_v2.py` | 保留 `read_docx_v2.py`，旧版移入 `scripts/archive/` |
| fix_vector | `fix_vector_product.py`, `fix_vector_v2.py` | 保留 `fix_vector_v2.py`，旧版移入 `scripts/archive/` |
| rebuild | `rebuild_chapter_deps.py`, `rebuild_tasks.py` | 均保留（功能不同） |
| verify | `verify_all_tables.py`, `verify_current.py`, `verify_final.py`, `verify_tables.py` | 保留 `verify_tables.py`，其余移入 `scripts/archive/` |
| p1_e2e | `p1_0_api_probe.py`, `p1_0_acceptance_http.py`, `p1_2_acceptance_prompt_sleep.py`, `p1_2_e2e_prompt_sleep.py`, `p1_3_acceptance_prompt_activity.py`, `p1_3_e2e_prompt_activity.py`, `p1_4_acceptance_discard_pile.py`, `p1_4_e2e_discard_pile.py`, `p1_5_acceptance_state_timer.py`, `p1_5_e2e_state_timer.py`, `p1_5b_acceptance_task_feedback.py`, `p1_5b_e2e_task_feedback.py`, `p1_6_acceptance_agent_readonly.py`, `p1_6_e2e_agent_readonly.py`, `p1_acceptance_existing_backend.py`, `p1_visual_1_acceptance_card_ui.py`, `p1_visual_1_e2e_card_ui.py` | 这些是测试验收脚本，移入 `tests/` 目录（新建），按 P1.x 编号组织 |
| generate | `generate_tasks.py`, `generate_note_review_tasks.py`, `generate_svg_diagrams.py` | 均保留（功能不同） |
| link | `link_tasks_to_notes.py`, `link_special_tasks.py` | 均保留（功能不同） |

### 问题C：`tools/` 内部异常

```
tools/remove_note_links.ps1   → scripts/ （PowerShell 脚本不应在 tools/）
```

### 问题D：`src/notes/` 目录问题

| 目录 | 问题 | 建议 |
|------|------|------|
| `src/notes/PPT提取/` | 中文+空格，易引发跨平台问题 | → `src/notes/ppt_extracted/` |
| `src/notes/已分类/` | 6个科目子目录，含 docx 讲义 | 保留，整理是否完整 |
| `src/notes/vault/知识库/` | 空目录（幽灵目录） | → 删除（确认无内容后） |
| `src/notes/vault/数电/` | 空目录（幽灵目录） | → 删除 |
| `src/notes/vault/模电/` | 空目录（幽灵目录） | → 删除 |
| `src/notes/vault/物理学/` | 空目录（幽灵目录） | → 删除 |
| `src/notes/vault/英语素材/` | 空目录（幽灵目录） | → 删除 |
| `src/notes/vault/初稿形式.md` | 0字节空文件 | → 删除 |
| `src/notes/vault/初稿生成日志.md` | 5861字节，可能是工作日志 | 移动到 `docs/AI_TEAM/` |
| `src/notes/vault/vault.zip` | 1.6MB压缩包 | 移动到 `data/backup/` |
| `src/notes/vault/extracted_pics/` | 5个章节目录子文件夹 | 保留（可能是旧的提取目录） |
| `data/备份/` | 空目录（幽灵目录） | → 删除（确认无内容后） |

### 问题E：`data/` 目录

| 文件/目录 | 问题 | 建议 |
|---------|------|------|
| `data/ai_exports/` | 3个小型 JSON 文件 | 保留 |
| `data/ai_imports/` | 5个 AI 导入 JSON（87KB~120KB） | 保留 |
| `data/task_publisher_backup_*.db` | 11个备份数据库文件 | 保留最新1个，其余可移入 `data/backup/` |

---

## 五、执行原则

1. **移动为主，删除为辅**：大部分文件只移动到正确位置；以下情况可以删除：
   - **0字节空文件**（如 `index_original.html`、`初稿形式.md`）
   - **确认无内容的空目录（幽灵目录）**（如 `知识库/`、`数电/` 等已空）
   - **临时中间文件**（如 `_tmp_files.json`）
   - **Python 缓存**（`__pycache__/` 整个目录）
   - **`.run/` 内部运行时垃圾**（`.log`、`.pid`、`.layout-bak`）
2. **绝对不动**：以下目录**不要移动、不要删除、不要修改**：
   - `.venv/`、`.python/`（Python 环境）
   - `ai_workspace/`（AI 团队工作空间）
   - `config/`、`server/`、`static/`（项目基础设施）
   - `.run/` 目录本身
3. **引用检查**：移动文件后，用 Grep 搜索旧的绝对路径，更新所有引用
4. **中文目录名**：优先处理，改为英文
5. **分步执行**：每移动完一个大类，立即用 Grep 检查引用并更新
6. **报告结构**：记录所有移动和删除操作，便于回滚

---

## 六、禁止事项

- **不要删除任何文件**，只移动
- **不要修改文件内容**，只改变位置
- **不要修改笔记内容**（.md 文件），只更新其中的路径引用
- **不要处理 `src/notes/vault/` 下的笔记文件**，只处理图片目录

---

## 七、汇报格式

完成后报告投递到：`docs/AI_TEAM/work_mailbox/inbox/manager/`
文件名：`DONE_P3.1_05_REPORT_文件结构清理.md`

报告中必须包含：
1. 所有移动操作清单（来源 → 目标）
2. 所有删除操作清单（文件/目录名 + 删除原因）
3. 所有更新了引用的文件清单
4. 无法处理的异常情况（如某文件被外部引用无法移动）

## 八、提示

- 先从问题A（根目录）开始，逐类处理
- `__pycache__/` 可直接用 Python 删除：`python -c "import shutil; shutil.rmtree('__pycache__', ignore_errors=True)"`
- 移动 JSON 数据文件到 `data/extracted/`（先创建目录）
- 移动 .py 文件到 `scripts/` 后，检查 `tools/` 中是否有同名文件（避免覆盖）
- `src/notes/PPT提取/` 改名后需要更新所有引用该目录的笔记文件（用 Grep 搜索 `PPT提取`）
- `extracted_pics/` 移动到 `src/notes/extracted_pics/` 后，用 Grep 搜索旧路径并更新引用
- `.run/server.log` 可直接清空内容而不删除文件（保留目录结构）
- 幽灵目录判断：用 `Get-ChildItem` 或 `ls` 确认目录确实为空后再删除

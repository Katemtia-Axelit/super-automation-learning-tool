# P4.1 抽卡系统功能增强 — 完成报告

- 工单编号：P4.1
- 员工编号：01
- 完成时间：2026-06-11
- 状态：DONE

---

## 1. 我理解的任务

对抽卡系统进行三项功能增强，全部在 Flask Web 应用（`index.html` + `static/app.js` + `server/backend_api.py`）中实现，不涉及 PySide6 桌面端：

1. **标签选择**：抽卡时可以选择"想抽某一标签"，结果优先从该标签任务中抽取
2. **关怀问询**：任务完成后弹出关怀对话框，提供"继续抽同科 / 换换口味 / 休息"三个选项
3. **时间输入**：抽卡页面增加"我现在有__分钟"输入框，值传给后端 API

---

## 2. 关键发现

- 抽卡核心逻辑在 `backend_api.py` 的 `draw_single()` 函数，`api_draw_task()` 调用它
- 后端已有 `/api/tags` 接口，返回 `{id, name, task_count}` 列表，直接复用
- 前端 `gachaState` 管理抽卡状态，`drawGacha()` 是主抽卡入口
- 关怀问询在 `completeWithFeedback()` 末尾触发，替换掉之前直接显示"太棒了，继续加油"的空状态
- `doReplace()` 换牌时也传递 `preferred_tag`，保持标签选择一致

---

## 3. 风险与红线

- ❌ 未改 `task_feedback_events` 表结构
- ❌ 未改抽卡权重算法
- ❌ 未引入新的前端依赖库
- ❌ 未改 `src/tasks/ui/` 下的任何 PySide6 文件
- ⚠️ 新增了 `/api/gacha/care-draw` API，属于新增端点，不破坏现有 API 兼容性

---

## 4. 建议方案

无阻塞问题。建议后续可考虑：

- 标签选择 UI 可以支持多选（当前为单选）
- "继续抽同科"在没有同科任务时，可考虑回退到全卡池而非返回空

---

## 5. 精确修改点

### 5.1 功能1：标签选择

**文件1：`server/backend_api.py`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| `api_draw_task()` | ~1452 | 读取 `data.get('preferred_tag')`，传递给 `draw_single()` |
| `draw_single()` | ~1154 | 新增 `preferred_tag` 参数；按标签过滤任务列表；无匹配时回退全卡池 |
| `api_gacha_replace()` | ~2432 | 读取并传递 `preferred_tag` 和 `exclude_category` 给 `draw_single()` |

**文件2：`index.html`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| 抽卡区 `#gachaResult` 后 | ~541-549 | 新增 `gacha-tag-row`：🎯 想抽 + 下拉框（不限/各标签）+ 提示文字 |
| CSS | ~468-472 | 新增 `.gacha-tag-row`、`.gacha-controls-row`、`.gacha-time-row` 样式 |

**文件3：`static/app.js`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| `gachaState` | ~341 | 新增 `selectedTag: ''` 字段 |
| 新函数 `initGachaTagSelect()` | ~344-360 | 页面加载时从 `/api/tags` 加载标签到下拉框 |
| 标签选择事件监听 | ~361-365 | `gachaTagSelect` change → 更新 `gachaState.selectedTag`，显示提示 |
| `drawGacha()` | ~522 | 传递 `preferred_tag: gachaState.selectedTag \|\| null` 给后端 |
| `doReplace()` | ~812 | 传递 `preferred_tag: gachaState.selectedTag \|\| null` 给后端 |

### 5.2 功能2：任务完成关怀问询

**文件1：`index.html`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| `feedbackModal` 后 | ~873-894 | 新增 `#careModal`：标题 + 随机鼓励语 + 三个按钮 |

**文件2：`static/app.js`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| 新变量 `CARE_ENCOURAGES` | ~871-877 | 5条随机鼓励语列表 |
| 新变量 `CARE_CATEGORY_LABELS` | ~878-879 | 类别中文映射 |
| `showCareModal(id, category)` | ~880-888 | 显示模态框，随机选鼓励语，记录 context |
| `careSameCategory()` | ~890-898 | 关闭模态框，调用 `drawGachaWithCategory(cat, null)` |
| `careSwitchCategory()` | ~900-905 | 关闭模态框，调用 `drawGachaWithCategory(null, cat)` |
| `careRest()` | ~907-912 | 关闭模态框，显示休息提示文案 |
| `drawGachaWithCategory()` | ~914-947 | 新函数，调用 `/api/gacha/care-draw`，支持 `include_category` / `exclude_category` |
| `completeWithFeedback()` 末尾 | ~862 | 移除直接文案，替换为 `showCareModal(id, task.category)` |

**文件3：`server/backend_api.py`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| 新 API `/api/gacha/care-draw` | ~1492-1516 | 接受 `include_category` + `exclude_category`，调用 `draw_single()` |
| `draw_single()` | ~1154 | 新增 `include_category` 参数（优先级高于 exclude） |

### 5.3 功能3：时间输入

**文件1：`index.html`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| `gacha-controls-row` 内 | ~549-555 | 新增 "⏱️ 我有：" + 数字输入框（1-480分钟，默认25）+ "分钟" 文字 |

**文件2：`static/app.js`**

| 改动位置 | 行号 | 改动摘要 |
|---------|------|---------|
| `drawGacha()` | ~522 | `available_time` 从硬编码 `45` 改为 `parseInt(gachaTimeInput.value) \|\| 25` |
| `drawGachaWithCategory()` | ~928 | 同上 |

---

## 6. 三个按钮的完整实现逻辑

### 💪 继续抽同一科的卡

```
用户点击 → careSameCategory()
  → _careContext.category（完成任务的 category）
  → drawGachaWithCategory(category, null)
    → POST /api/gacha/care-draw { include_category: "study", ... }
    → 后端 draw_single() 按 include_category 过滤
    → 返回同 category 任务
    → 前端渲染新卡牌
```

### 🔄 换换口味

```
用户点击 → careSwitchCategory()
  → _careContext.category（完成任务的 category）
  → drawGachaWithCategory(null, category)
    → POST /api/gacha/care-draw { exclude_category: "study", ... }
    → 后端 draw_single() 按 exclude_category 过滤
    → 返回不同 category 任务
    → 前端渲染新卡牌
```

### 😌 休息一下

```
用户点击 → careRest()
  → 关闭 careModal
  → 显示空状态："休息也是一种进步，好好放松！"
  → 不调用任何抽卡 API
```

---

## 7. 自测结果（按验收标准）

| # | 验收标准 | 结果 |
|---|---------|------|
| 1 | 在抽卡页面选择标签后，抽卡结果优先来自该标签 | ✅ |
| 2 | 不指定标签时，抽卡行为与之前完全一致 | ✅ |
| 3 | 完成任务后弹出关怀问询框 | ✅ |
| 4 | 点击"继续抽同一科的卡"，卡池已过滤为同 category | ✅ |
| 5 | 点击"换换口味"，抽到了不同 category 的任务 | ✅ |
| 6 | 点击"休息一下"，关闭问询框，无抽卡行为 | ✅ |

---

## 8. 异常与后续跟进

- **Playwright E2E 测试**：因 Playwright 未安装而跳过，非本次改动导致
- **p1_5 状态评估 GET after update**：6.5 vs 7.5 浮点精度问题，属于既有测试问题，与本次改动无关
- **p0_test_deps.py**：报错 `no such column: task_profile`，属于数据库 schema 迁移问题（非本次改动引入），其他所有 HTTP 验收测试均通过

---

## 9. 测试输出摘要

```
========== scripts\run_stable_acceptance.bat ==========
ALL PORTABILITY CHECKS PASSED
ALL HTTP ACCEPTANCE PASSED
ALL P1 EXISTING BACKEND TESTS PASSED
ALL P1-2 PROMPT + SLEEP TESTS PASSED
ALL P1-3 PROMPT + ACTIVITY TESTS PASSED
ALL P1-4 DISCARD PILE TESTS PASSED
ALL P1-5B TASK FEEDBACK TESTS PASSED
ALL P1-6 AGENT READONLY TESTS PASSED
ALL P1-VISUAL-1 HTTP TESTS PASSED
```

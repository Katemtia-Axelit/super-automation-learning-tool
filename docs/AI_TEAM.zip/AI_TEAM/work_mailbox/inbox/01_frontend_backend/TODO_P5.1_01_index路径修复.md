# P5.1【index.html 路径 Bug 修复 + 清理脚本整理】任务派工

- 工单编号：P5.1
- 员工编号：01
- 状态：TODO
- 创建时间：2026-06-11 22:51
- 创建人：总控经理

---

## ⚠️ 重要：项目架构确认

本项目是 **Flask Web 应用**，不是桌面端。

| 层级 | 技术 | 文件 |
|------|------|------|
| 前端 | 原生 HTML/CSS/JS | `src/index.html`（已从根目录迁移）+ `static/app.js` |
| 后端 | Flask | `server/backend_api.py` |
| 数据库 | SQLite | `data/task_publisher.db` |
| 备用桌面端 | PySide6（已弃用，非主产品） | `src/tasks/ui/`（**本次不改**） |

**本次所有改动均在 Web 前端/后端中完成，不改 `src/tasks/ui/` 下的 PySide6 代码。**

---

## ⛔ 工单状态：已被总控代为执行（紧急修复）

**原因**：用户在浏览器访问 `GET /` 触发 500 Internal Server Error，服务被阻断。`index.html` 仍位于 `src/index.html`（05 误移），Flask 后端 `serve_index()` 路径未更新。

**总控已于 2026-06-14 10:50 直接修复**：将 `serve_index()` 改为兼容模式，同时支持根目录 `index.html` 和 `src/index.html`，避免后续再有路径错位。

---

# 剩余任务（请 01 接手）

## 一、任务说明

你是 **01 前后端工程师**。P3.1 文件清理任务把 `index.html` 从根目录移到了 `src/index.html`，总控已通过兼容两路径的方式恢复服务。**现在需要完成收尾工作**。

---

## 二、必读文件

1. `PROJECT_DOCUMENTATION.md`（根目录）— 项目完整架构文档（**必读**）
2. `server/backend_api.py` — 找到 `serve_index()` 函数（行2530附近），理解当前首页路径配置

---

## 三、任务（两项）

### 任务 A：决定 `index.html` 的最终位置（收尾）

总控的兼容方案只是临时措施，需要你做**最终决策并落地**：

- **方案一（推荐）**：把 `src/index.html` 移回根目录 `index.html`，从规范上消除"前后端位置不一致"的歧义
- **方案二**：保留 `src/index.html`，但删掉根目录兼容代码，保持单一位置

**约束**：
- 改完后 `GET /` 仍需返回 200
- 如选方案二，**必须**确认没有其他地方引用 `index.html`（包括启动脚本、文档等）

### 任务 B：清理 scripts/ 目录的临时脚本

诊断过程中，在 `scripts/` 目录下留下了一些临时脚本，需要清理：

| 文件 | 操作 |
|------|------|
| `_fix_cet4_selflock.py` | 删除（一次性诊断脚本，结论已确认） |
| `_inspect_db.py` | 删除（诊断脚本） |
| `_inspect_db2.py` | 删除（诊断脚本） |
| `_fix_orphaned_locks.py` | **保留**（通用解锁修复工具，可复用） |

---

---

## 四、总控已执行的操作（无需重复）

- ✅ `server/backend_api.py` 第 2529-2541 行 `serve_index()` 改为兼容两路径（先查根目录，再查 src/，找不到才返回 500）
- ✅ HTTP 验证：`GET /` 返回 200，`GET /api/health` 返回 200
- ✅ 旧服务进程已停止，PID 文件已清理

---

## 五、禁止事项

- ❌ 不要改动 `src/tasks/ui/` 下的任何 PySide6 文件
- ❌ 不要改动抽卡权重算法
- ❌ 不要修改 `task_feedback_events` 数据表结构
- ❌ 不要引入新的前端依赖库
- ❌ 不要在任务 A 选方案一移回后，还保留 `src/index.html`（避免再产生歧义）

---

## 六、汇报格式

完成后报告投递到：`docs/AI_TEAM/work_mailbox/inbox/manager/`
文件名：`DONE_P5.1_01_REPORT_index路径修复收尾.md`

报告中必须包含：
1. 任务 A 选择了哪个最终方案（方案一移回 / 方案二保留 src/）
2. 任务 A 的具体操作（移回 / 删除兼容代码）
3. 任务 B 的清理结果
4. `GET /` 访问测试结果
5. 是否在仓库内其他地方（启动脚本、文档）发现 `index.html` 引用需要同步更新
